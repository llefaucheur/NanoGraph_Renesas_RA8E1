src/NanoGraph/NanoGraph_Platform/top_manifest.o: \
 ../src/NanoGraph/NanoGraph_Platform/top_manifest.c \
 ../src/NanoGraph/NanoGraph_Platform/../nanograph_interpreter.h \
 ../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Store/nanograph_store_common_const.h \
 ../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Store/nanograph_store_common_types.h \
 ../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Interpreter/nanograph_const.h \
 ../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Interpreter/../top_manifest_included.h \
 ../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Interpreter/../NanoGraph_Platform/top_manifest.h \
 ../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Interpreter/nanograph_types.h \
 ../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Interpreter/nanograph_const.h \
 ../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Interpreter/nanograph_extern.h \
 ../src/NanoGraph/NanoGraph_Platform/top_manifest.h \
 ../src/NanoGraph/NanoGraph_Platform/graphs/graph_bin.txt
../src/NanoGraph/NanoGraph_Platform/../nanograph_interpreter.h:
../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Store/nanograph_store_common_const.h:
../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Store/nanograph_store_common_types.h:
../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Interpreter/nanograph_const.h:
../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Interpreter/../top_manifest_included.h:
../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Interpreter/../NanoGraph_Platform/top_manifest.h:
../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Interpreter/nanograph_types.h:
../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Interpreter/nanograph_const.h:
../src/NanoGraph/NanoGraph_Platform/../NanoGraph_Interpreter/nanograph_extern.h:
../src/NanoGraph/NanoGraph_Platform/top_manifest.h:
../src/NanoGraph/NanoGraph_Platform/graphs/graph_bin.txt:
