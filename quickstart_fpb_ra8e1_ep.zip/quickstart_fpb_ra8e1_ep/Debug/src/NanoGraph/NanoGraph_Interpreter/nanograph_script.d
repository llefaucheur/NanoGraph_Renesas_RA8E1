src/NanoGraph/NanoGraph_Interpreter/nanograph_script.o: \
 ../src/NanoGraph/NanoGraph_Interpreter/nanograph_script.c
