src/NanoGraph/NanoGraph_Interpreter/nanograph_script_process.o: \
 ../src/NanoGraph/NanoGraph_Interpreter/nanograph_script_process.c
