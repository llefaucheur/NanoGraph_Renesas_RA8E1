src/NanoGraph/main_call.o: ../src/NanoGraph/main_call.c \
 ../src/NanoGraph/top_manifest_included.h \
 ../src/NanoGraph/NanoGraph_Platform/top_manifest.h \
 ../src/NanoGraph/nanograph_common.h \
 ../src/NanoGraph/NanoGraph_Store/nanograph_store_common_const.h \
 ../src/NanoGraph/NanoGraph_Store/nanograph_store_common_types.h \
 ../src/NanoGraph/nanograph_interpreter.h \
 ../src/NanoGraph/NanoGraph_Interpreter/nanograph_const.h \
 ../src/NanoGraph/NanoGraph_Interpreter/../top_manifest_included.h \
 ../src/NanoGraph/NanoGraph_Interpreter/../NanoGraph_Platform/top_manifest.h \
 ../src/NanoGraph/NanoGraph_Interpreter/nanograph_types.h \
 ../src/NanoGraph/NanoGraph_Interpreter/nanograph_const.h \
 ../src/NanoGraph/NanoGraph_Interpreter/nanograph_extern.h
../src/NanoGraph/top_manifest_included.h:
../src/NanoGraph/NanoGraph_Platform/top_manifest.h:
../src/NanoGraph/nanograph_common.h:
../src/NanoGraph/NanoGraph_Store/nanograph_store_common_const.h:
../src/NanoGraph/NanoGraph_Store/nanograph_store_common_types.h:
../src/NanoGraph/nanograph_interpreter.h:
../src/NanoGraph/NanoGraph_Interpreter/nanograph_const.h:
../src/NanoGraph/NanoGraph_Interpreter/../top_manifest_included.h:
../src/NanoGraph/NanoGraph_Interpreter/../NanoGraph_Platform/top_manifest.h:
../src/NanoGraph/NanoGraph_Interpreter/nanograph_types.h:
../src/NanoGraph/NanoGraph_Interpreter/nanograph_const.h:
../src/NanoGraph/NanoGraph_Interpreter/nanograph_extern.h:
