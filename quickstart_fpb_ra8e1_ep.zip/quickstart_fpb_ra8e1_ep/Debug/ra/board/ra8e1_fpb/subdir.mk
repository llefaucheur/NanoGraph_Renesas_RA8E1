################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/board/ra8e1_fpb/board_init.c \
../ra/board/ra8e1_fpb/board_leds.c 

C_DEPS += \
./ra/board/ra8e1_fpb/board_init.d \
./ra/board/ra8e1_fpb/board_leds.d 

OBJS += \
./ra/board/ra8e1_fpb/board_init.o \
./ra/board/ra8e1_fpb/board_leds.o 

SREC += \
quickstart_fpb_ra8e1_ep.srec 

MAP += \
quickstart_fpb_ra8e1_ep.map 


# Each subdirectory must supply rules for building sources it contributes
ra/board/ra8e1_fpb/%.o: ../ra/board/ra8e1_fpb/%.c
	$(file > $@.in,-mthumb -mfloat-abi=hard -mcpu=cortex-m85+nopacbti -O0 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -fno-strict-aliasing -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -D_RENESAS_RA_ -D_RA_CORE=CM85 -D_RA_ORDINAL=1 -I"C:/Users/laulef01/e2_studio/workspace2/quickstart_fpb_ra8e1_ep/src" -I"." -I"C:/Users/laulef01/e2_studio/workspace2/quickstart_fpb_ra8e1_ep/ra/fsp/inc" -I"C:/Users/laulef01/e2_studio/workspace2/quickstart_fpb_ra8e1_ep/ra/fsp/inc/api" -I"C:/Users/laulef01/e2_studio/workspace2/quickstart_fpb_ra8e1_ep/ra/fsp/inc/instances" -I"C:/Users/laulef01/e2_studio/workspace2/quickstart_fpb_ra8e1_ep/ra/arm/CMSIS_6/CMSIS/Core/Include" -I"C:/Users/laulef01/e2_studio/workspace2/quickstart_fpb_ra8e1_ep/ra_gen" -I"C:/Users/laulef01/e2_studio/workspace2/quickstart_fpb_ra8e1_ep/ra_cfg/fsp_cfg/bsp" -I"C:/Users/laulef01/e2_studio/workspace2/quickstart_fpb_ra8e1_ep/ra_cfg/fsp_cfg" -std=c99 -Wno-stringop-overflow -Wno-format-truncation -flax-vector-conversions --param=min-pagesize=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

