/***********************************************************************************************************************
* Copyright (c) 2024 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name    : user_main.c
 * Version      : .
 * OS           : .
 * H/W Platform : FPB-RA4T1
 * Description  : This file includes the main tutorial code.
 * Operation    : See readme.txt
 * Limitations  : .
 *********************************************************************************************************************/


#include "hal_data.h"

typedef struct irq_pins
{
    const external_irq_instance_t * const p_irq;
} st_irq_pins_t;

extern const bsp_leds_t g_bsp_leds;

/**********************************************************************************************************************
 * Function Name: st_irq_pins_t;
 * Description  : stores location of the pins used for irqs
 * Argument     : s_irq_pins
 * Return Value : .
 *********************************************************************************************************************/
static st_irq_pins_t s_irq_pins[] =
{
    { &g_external_irq13 }
};
/**********************************************************************************************************************
 End of function st_irq_pins_t
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * Function Name: icu_initialize
 * Description  : initialises irq pins to allow for button presses
 * Return Value : fsp_err
 *********************************************************************************************************************/
static fsp_err_t icu_initialize(void)
{
    uint8_t g_irq_switch = ((sizeof(s_irq_pins)) / (sizeof(s_irq_pins[0]))); /*  */
    fsp_err_t fsp_err = FSP_SUCCESS;
    for (uint32_t i = 0; i < g_irq_switch; i++)
    {
        fsp_err = R_ICU_ExternalIrqOpen (s_irq_pins[i].p_irq->p_ctrl, s_irq_pins[i].p_irq->p_cfg);
        if (FSP_SUCCESS != fsp_err) return fsp_err;

        fsp_err = R_ICU_ExternalIrqEnable (s_irq_pins[i].p_irq->p_ctrl);
        if (FSP_SUCCESS != fsp_err) return fsp_err;
    }
    return fsp_err;
}
/**********************************************************************************************************************
 End of function icu_initialize
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * Function Name: user_main
 * Description  : .
 * Return Value : .
 *********************************************************************************************************************/
extern void user_main(void);
void user_main(void)
{
    extern uint32_t BareMetalTaskHandle;
    bsp_leds_t leds = g_bsp_leds;

    icu_initialize();
    bsp_io_level_t pin_level1 = BSP_IO_LEVEL_HIGH;
    bsp_io_level_t pin_level2 = BSP_IO_LEVEL_HIGH;

    extern void main_init(uint32_t *graph);
                main_init (0);
    extern void SysTickSetup (void);
                SysTickSetup ();

    while (1)
    {
//        R_BSP_PinAccessEnable();
//        if (BareMetalTaskHandle & BareMetalTaskHandle0_mask) /* check thread 0 */
//        {   R_BSP_PinWrite((bsp_io_port_pin_t)leds.p_leds[0], pin_level1);
//            pin_level1 = !pin_level1;
//            BareMetalTaskHandle = BareMetalTaskHandle & (uint32_t)(~BareMetalTaskHandle0_mask);
//        }
//        if (BareMetalTaskHandle & BareMetalTaskHandle1_mask) /* check thread 1 */
//        {   R_BSP_PinWrite((bsp_io_port_pin_t)leds.p_leds[1], pin_level2);
//            pin_level2 = !pin_level2;
//            BareMetalTaskHandle = BareMetalTaskHandle & (uint32_t)(~BareMetalTaskHandle1_mask);
//        }
//        R_BSP_PinAccessDisable();
        __WFI();

        extern void main_run(void);
        main_run();
    }
}
/**********************************************************************************************************************
 End of function user_main
 *********************************************************************************************************************/

/** External IRQ for SW 1 on ICU Instance. */
/**********************************************************************************************************************
 * Function Name: callback_irq13_button
 * Description  : .
 * Argument     : p_args
 * Return Value : .
 *********************************************************************************************************************/
void callback_irq13_button(external_irq_callback_args_t *p_args)
{
    FSP_PARAMETER_NOT_USED(p_args);
    /* 
        CODE TO ADD */
}
/**********************************************************************************************************************
 End of function callback_irq13_button
 *********************************************************************************************************************/
